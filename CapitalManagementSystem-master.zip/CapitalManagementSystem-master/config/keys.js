module.exports = {
  // mongoURI:"mongodb+srv://test:testpassword@restful-api-prod-potjy.mongodb.net/test?retryWrites=true&w=majority",
  mongoURI:"mongodb+srv://admin:adminpassword@data-api-8bdik.mongodb.net/test?retryWrites=true&w=majority",
  secretOrKey:"secret"
}