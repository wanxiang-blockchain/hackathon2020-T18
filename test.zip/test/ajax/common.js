var xmlhttp;


var obutton = document.getElementById("btn_submit").getElementsByTagName("button");
for (let i = 0; i < obutton.length; i++) {
    obutton[i].onclick = function(){
        //onSubmit(obutton.length-i);
        if( i < obutton.length-1)
        {
            onSubmit(i+1);
        }
        else
        {
            window.close();
        }
        
    }
}


function onSubmit(catalog_id) {
    console.log("----------------------------------------------");
    console.log("----------------------------------------------");

    if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = ajaxCallback;
        var webTitle = document.getElementById('webTitle').value;
        var webLink = document.getElementById('webLink').value;
        var webSelection = document.getElementById('webSelection').value;
        //var str = webTitle + webLink + webSelection;
        console.log(webTitle);
        //xmlhttp.open("GET","http://103.200.112.151:11000/ajax/test.php?chrome="+str, true);
        //xmlhttp.open("GET", "http://127.0.0.1:8001/ajax/test.php?chrome=" + str, true);
        //xmlhttp.send();
        var acion_url = "http://127.0.0.1:8001/ajax/note.php";
        xmlhttp.open("POST", acion_url, true);
        var content = 'action=addNote' + '&webTitle=' + webTitle
            + '&webLink=' + webLink + '&webSelection=' + webSelection + '&catalog_id=' + catalog_id;
        xmlhttp.setRequestHeader("Content-Type",
            "application/x-www-form-urlencoded");
        //xmlhttp.setRequestHeader("Content-Length", content.length);

        xmlhttp.send(content);
        document.getElementById('webResult').innerHTML = "发送中……";

    }
    else {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
}


function ajaxCallback() {
    if (xmlhttp.readyState < 4) {
        //document.getElementById('webResult').innerHTML = "<span style=\"color: red;\">失败</span>";
        return;
    };
    if (xmlhttp.status !== 200) {
        //alert('the status code is not ok');
        document.getElementById('webResult').innerHTML = "<span style=\"color: red;\">失败</span>";
        return;
    };
    //alert(xhr.responseText);

    //document.getElementById('webTitle').value = "保存成功";

    if ("success" == xmlhttp.responseText) {
        document.getElementById('webResult').innerHTML = "保存成功";
        window.close();
    }
    else {
        document.getElementById('webResult').innerHTML = "<span style=\"color: red;\">失败</span>";
    }

    //document.close();
    // setTimeout(function () {  window.close(); }, 500)
}
