<?php

//支持跨域提交
header("Access-Control-Allow-Origin: *");
//设置北京时间
date_default_timezone_set("PRC"); 

@$Server = "127.0.0.1";
$database = "web_track_note";
$uid = "root";
$pwd = "root";
$table = "webnote";
$link = mysqli_connect($Server, $uid, $pwd, $database);

$action = trim($_REQUEST['action']); //接收前端传来的数据 

if ($action == "addNote") {
    $result = 0;
    @$note_title = mysqli_real_escape_string($link, trim($_REQUEST['webTitle'])); //接收前端传来的数据 
    @$note_url = trim($_REQUEST['webLink']); //接收前端传来的数据 
    @$note_selection = mysqli_real_escape_string($link, trim($_REQUEST['webSelection']));  //接收前端传来的数据 
    @$note_addtime = date("Y-m-d H:i:s");; //接收前端传来的数据 
    @$note_edittime = date("Y-m-d H:i:s"); //插入时间
    @$catalog_id = $_REQUEST['catalog_id']; //插入时间


    if ($link) {
        //echo "Connection established.\n";
        $sql = "INSERT INTO $table (note_title, note_url, note_selection, note_addtime, note_edittime, catalog_id) VALUES ('$note_title', '$note_url', '$note_selection','$note_addtime', '$note_edittime', $catalog_id)";       
         //$sql = "INSERT INTO dbo.userinfo (userName, userPass) VALUES ('$title', '$description')";
        $data = mysqli_query($link, $sql);

        if ($data === false) {
            //print "error";
        } else {
            $result = 1;
        }
    } else {
        print_r(sqlsrv_errors(), true);
        die("");
    }

    if ($result) {
        echo "success";
    } else {
        echo "fail";
    }
}
