<?php
    header("Access-Control-Allow-Origin: *");
    @$line = $_REQUEST["chrome"];
    $datetime = date("Y-m-d H:i:s");
    $myfile = fopen("newfile.txt", "a") or die("Unable to open file!");
    
    fwrite($myfile, $datetime);
    fwrite($myfile, "\r\n");
    if(isset($line))
    {
        fwrite($myfile, $line);
        fwrite($myfile, "\r\n");
    }
    echo $datetime;
    fclose($myfile);

