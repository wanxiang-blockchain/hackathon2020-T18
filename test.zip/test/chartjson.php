<?php
header('Content-Type:application/json'); //这个类型声明非常关键
?>
{
"name": "浙江",
"children": [
{
"name": "捐出"
}
]
}