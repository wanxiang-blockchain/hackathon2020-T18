<?php
$Server = "127.0.0.1";
$database = "xidian2020";
$uid = "root";
$pwd = "root";
$table = "donation";
$conInfo = array('Database' => $database, 'UID' => $uid, 'PWD' => $pwd, "CharacterSet" => "UTF-8");
$link = mysqli_connect($Server, $uid, $pwd, $database);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>应急救灾物资管理</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="dist/eui/2.12.0/index.css">

</head>

<body>

  <!--==========================
  Header
  ============================-->
  <header id="header" class="fixed-top">
    <div class="container">

      <div class="logo float-left">
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <h1 class="text-light"><a href="#header"><span>NewBiz</span></a></h1> -->
        <a href="#intro" class="scrollto"><img src="img/logo.png" alt="" class="img-fluid"></a>
      </div>

      <nav class="main-nav float-right d-none d-lg-block">
        <ul>
        <li><a href="index.html">首页</a></li>
          <li><a href="donation.html">在线捐赠</a></li>
          <li><a href="requirement.html">发布需求</a></li> 
          <li class="active"><a href="blockchain.html">区块链</a></li>
          <li><a href="login.html">物资管理</a></li>
          <li><a href="statistics.html">全球疫情统计</a></li>
        </ul>
      </nav><!-- .main-nav -->

    </div>
  </header><!-- #header -->



  <main id="main">

    <!--==========================
      About Us Section
    ============================-->
    <section id="about">

      <div class="container">

        <header class="section-header">
          <p></p>
          <p></p>
          <h3>区块链信息</h3>


          <div id="qrcode" style="width:100px; height:100px; margin:auto;"></div>



          <div class="card-body" id="app">

            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <!--th>证据ID</th-->
                    <th>区块哈希</th>
                    <th>交易数量</th>
                    <th>时间</th>

                  </tr>
                </thead>

                <tbody>
                  <tr>

                    <td>{{ hash(postList.req_id + postList.req_datetime) }}...
                    </td>
                    <td style="max-width:500px">{{ translength }}</td>
                    <td style="max-width:500px">{{ postList.don_datetime }}</td>
                  </tr>
                </tbody>
              </table>

              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                

                <tbody>
                  <tr>
                    <td style="max-width:500px">捐赠时间</td>
                    <td style="max-width:500px">{{ postList.don_datetime }}</td>
                  </tr>
                  <tr>
                    <td style="max-width:500px">捐赠方</td>
                    <td style="max-width:500px">{{ postList.don_donor }}</td>
                  </tr>
                  <tr>
                    <td style="max-width:500px">物品编号</td>
                    <td style="max-width:500px">{{ postList.product_id }}</td>
                  </tr>
                  <tr>
                    <td style="max-width:500px">捐赠数量</td>
                    <td style="max-width:500px">{{postList.don_quantity}}</td>
                  </tr>
                  
                </tbody>
              </table>
              <svg width="960" height="600"></svg>

              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>交易时间</th>
                    <th>接收方</th>

                    <th>转移数量</th>


                  </tr>
                </thead>

                <div v-if="trackList.length > 0">
                  <div v-for="(item, index) in trackList">
                    <span> </span></p>
                  </div>
                </div>



                <tbody v-for="(item, index) in trackList">
                  <tr>
                    <!--td>[{{ index+1 }}] </td-->


                    <td style="max-width:500px">{{ item.dis_datetime }}</td>
                    <td style="max-width:500px">
                      {{ item.req_recipient }}
                    </td>
                    <td>{{ item.dis_quantity }} {{ item.product_unit }}</td>
                  </tr>
                </tbody>
              </table>
              </div-->





            </div>




        </header>



      </div>
      <div class="wrapper" style="margin: auto; width:1024px"><canvas id="chart-0"></canvas></div>
    </section><!-- #about -->


  </main>

  <!--==========================
    Footer
  ============================-->
  <footer id="footer">


    <div class="container">
      <div class="copyright">
        <span>&copy; 2020 西安电子科技大学</span><br />
        All Rights Reserved
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- Uncomment below i you want to use a preloader -->
  <!-- <div id="preloader"></div> -->

  <!-- Bootstrap core JavaScript-->
  <script src="dist/vue.js"></script>
  <!-- Add this after vue.js -->
  <script src="dist/eui/2.12.0/index.js"></script>
  <script src="dist/axios.min.js"></script>
  <script src="dist/vue-router.js"></script>
  <script src="md5.js"></script>
  <script type="text/javascript" src="qrcode.js"></script>
  <script src="assets/plugins/jquery/jquery.min.js"></script>
  <script src="assets/plugins/charts/Chart.min.js"></script>
  <script src="assets/js/chart.js"></script>
  <script src="https://www.chartjs.org/samples/latest/utils.js"></script>
  <script src="https://d3js.org/d3.v5.min.js"></script>
  <script>
    //----------------------------------


    //定义边界
    var marge = {
      top: 50,
      bottom: 0,
      left: 10,
      right: 0
    };

    var svg = d3.select("svg");
    var width = svg.attr("width");
    var height = svg.attr("height");

    var g = svg.append("g")
      .attr("transform", "translate(" + marge.top + "," + marge.left + ")");

    var scale = svg.append("g")
      .attr("transform", "translate(" + marge.top + "," + marge.left + ")");

    <?php


    @$don_id = $_REQUEST['block_id'];

    $result = 0;
    $don_quantity = 0;
    if ($link) {
      //echo "Connection established.\n";
      //@$page_num = trim($_REQUEST['page_num']);

      // $page_num = $page_num * $row_per_page;
      //$sql = "SELECT TOP 10 * FROM dbo.question where post_id = $post_id order by question_id desc";

      $sql = "SELECT * FROM $table where don_id = $don_id";
      $data = mysqli_query($link, $sql);
      $row = mysqli_fetch_array($data);
      $don_quantity = $row['don_quantity'];

    ?>

      //数据
      var dataset = {
        name: <?php echo "\"" . $row["don_donor"] . "\"" ?>,
        children: [{
          name: "捐出",
          children: [
            <?php
          }

          $dataChart = array();
          if ($link) {
            //echo "Connection established.\n";
            @$don_id = trim($_REQUEST['block_id']);

            // $page_num = $page_num * $row_per_page;
            //$sql = "SELECT TOP 10 * FROM dbo.question where post_id = $post_id order by question_id desc";
            $sql = "SELECT * FROM disclosure, product, requirement where disclosure.don_id = $don_id and disclosure.product_id = product.product_id and disclosure.req_id = requirement.req_id order by dis_id desc";
            //$sql = "SELECT * FROM  product";

            // echo $sql;
            //$sql = "SELECT TOP 20 * FROM dbo.post order by post_id desc";

            $data = mysqli_query($link, $sql);


            while ($row = mysqli_fetch_array($data, MYSQLI_ASSOC)) {
              // print_r($row);
              $dataChart[] = $row;
            ?>

              {
                name: <?php echo "\"" . $row['req_recipient'] . ' 交易时间：' . $row['dis_datetime'] . "\"" ?>,
                value: 100
              },

          <?php


            }
          }


          ?>


          ]
        }, ]
      };



      var hierarchyData = d3.hierarchy(dataset)
        .sum(function(d) {
          return d.value;
        });

      //创建一个树状图
      var tree = d3.tree()
        .size([width - 400, height - 200])
        .separation(function(a, b) {
          return (a.parent == b.parent ? 1 : 2) / a.depth;
        })

      //初始化树状图，也就是传入数据,并得到绘制树基本数据
      var treeData = tree(hierarchyData);
      console.log(treeData);
      //得到节点
      var nodes = treeData.descendants();
      var links = treeData.links();

      //输出节点和边
      console.log(nodes);
      console.log(links);

      //创建一个贝塞尔生成曲线生成器
      var Bézier_curve_generator = d3.linkHorizontal()
        .x(function(d) {
          return d.y;
        })
        .y(function(d) {
          return d.x;
        });

      //有了节点和边集的数据后，我们就可以开始绘制了，
      //绘制边
      g.append("g")
        .selectAll("path")
        .data(links)
        .enter()
        .append("path")
        .attr("d", function(d) {
          var start = {
            x: d.source.x,
            y: d.source.y
          };
          var end = {
            x: d.target.x,
            y: d.target.y
          };
          return Bézier_curve_generator({
            source: start,
            target: end
          });
        })
        .attr("fill", "none")
        .attr("stroke", "blue")
        .attr("stroke-width", 1);

      //绘制节点和文字
      //老规矩，先创建用以绘制每个节点和对应文字的分组<g>
      var gs = g.append("g")
        .selectAll("g")
        .data(nodes)
        .enter()
        .append("g")
        .attr("transform", function(d) {
          var cx = d.x;
          var cy = d.y;
          return "translate(" + cy + "," + cx + ")";
        });
      //绘制节点
      gs.append("circle")
        .attr("r", 6)
        .attr("fill", "white")
        .attr("stroke", "green")
        .attr("stroke-width", 1);

      //文字
      gs.append("text")
        .attr("x", function(d) {
          return d.children ? -40 : 8;
        })
        .attr("y", -15)
        .attr("dy", 10)
        .text(function(d) {
          return d.data.name;
        });



      function drawsvg() {


      }


      ////------------------------------------------------------------------

      var DATA_COUNT = 16;
      var MIN_XY = 0;
      var MAX_XY = 100;

      var utils = Samples.utils;

      utils.srand(110);

      function colorize(opaque, context) {
        var value = context.dataset.data[context.dataIndex];
        var x = value.x / 100;
        var y = value.y / 100;
        var r = x < 0 && y < 0 ? 250 : x < 0 ? 150 : y < 0 ? 50 : 0;
        var g = x < 0 && y < 0 ? 0 : x < 0 ? 50 : y < 0 ? 150 : 250;
        var b = x < 0 && y < 0 ? 0 : x > 0 && y > 0 ? 250 : 150;
        var a = opaque ? 1 : 0.5 * value.v / 1000;

        return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
      }
      var data = {
        datasets: [{
          data: [
            {x:0, y:<?php echo $don_quantity ?>, v:  <?php echo intval($don_quantity)*100+200 ?> },
           <?php   
          

           for($index = 0; $index<count($dataChart); $index++)
           {

           echo "{";
           echo "x:". ($index+1) .",";
           echo "y:". $dataChart[$index]['dis_quantity'] .",";
           echo "v:". (floatval($dataChart[$index]['dis_quantity'])*100 +200) ."";
          
          echo "},";
        }
           ?> 
           
        
        ]
        }]
      };

      var options = {
        aspectRatio: 1,
        legend: false,
        tooltips: false,

        elements: {
          point: {
            backgroundColor: colorize.bind(null, false),

            borderColor: colorize.bind(null, true),

            borderWidth: function(context) {
              return Math.min(Math.max(1, context.datasetIndex + 1), 8);
            },

            hoverBackgroundColor: 'transparent',

            hoverBorderColor: function(context) {
              return utils.color(context.datasetIndex);
            },

            hoverBorderWidth: function(context) {
              var value = context.dataset.data[context.dataIndex];
              return Math.round(8 * value.v / 1000);
            },

            radius: function(context) {
              var value = context.dataset.data[context.dataIndex];
              var size = context.chart.width;
              var base = Math.abs(value.v) / 1000;
              return (size / 24) * base;
            }
          }
        }
      };

      var chart = new Chart('chart-0', {
        type: 'bubble',
        data: data,
        options: options
      });



      var qrcode = new QRCode(document.getElementById("qrcode"), {
        width: 100,
        height: 100
      });


      let block_id = getQueryString('block_id');

      function makeCode() {

        qrcode.makeCode(hex_md5(block_id));
      }

      makeCode();

      function getQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]);
        return null;
      }


      var api_url = "api.web.hash.php"


      console.log('createdList')

      var app5 = new Vue({
        el: '#app',
        data: {
          doc_id: 0,
          deviceList: [],
          doc_title: "",
          doc_content: "",
          doc_model: "",
          tipMessage: "",
          logList: [],
          editMode: false,
          log_date: "",
          dataList: [],
          search_value: "",
          date_start: "",
          date_end: "",
          trackList: [],
          postList: [],
          translength: 0,
          detailDialogVisible: false,
          current_id: 0
        },



        methods: {

          addLog: function() {
            var that = this;
            axios.get(api_url, {
                params: {
                  action: "addLog",
                  doc_id: that.device_id,
                  log_title: that.log_title,
                  log_date: that.log_date
                  /*
         doc_url: this.device_url,
         doc_content: this.device_content,
         doc_deadline: this.device_deadline,
         doc_model: this.device_model
          */

                }
              })
              .then(function(response) {
                //JSON.parse(response.data);
                console.log(response.data);
                console.log(response.data['code']);
                if (response.data['code'] == 1) {
                  that.getLogList()
                  that.refreshLog()
                  //window.location.href = './index.html';
                }


              })
              .catch(function(error) {
                console.log(error);
              });

          },

          handleClose: function() {
            var that = this;
            that.detailDialogVisible = false;
          },

          viewDetail: function(index_id) {
            var that = this;
            that.detailDialogVisible = true
            that.current_id = index_id;
            that.getTracking(that.dataList[index_id].don_id);
          },

          getTracking: function(donation_id) {
            var that = this;
            axios.get(api_url, {
                params: {
                  action: 'getTracking',
                  don_id: donation_id
                }
              })
              .then(function(response) {
                if (response.status == 200) {
                  //post_list = response.data[0]
                  // console.log(post_list)
                  that.trackList = response.data;
                  that.translength = that.trackList.length
                  console.log(that.trackList)
                }


              })
              .catch(function(error) {
                console.log(error);
              });

          },

          getPost: function(donation_id) {
            var that = this;
            axios.get(api_url, {
                params: {
                  action: 'getPost',
                  don_id: donation_id
                }
              })
              .then(function(response) {
                if (response.status == 200) {
                  //post_list = response.data[0]
                  // console.log(post_list)
                  that.postList = response.data;
                  console.log(that.trackList)
                }


              })
              .catch(function(error) {
                console.log(error);
              });

          },


          searchDevice: function() {
            var that = this;
            //that.editMode = true


          },



          refreshForm: function() {
            var that = this;

            that.editMode = false;
          },

          refreshLog: function() {
            var that = this;

            that.log_title = '';
            that.log_date = todayTime();

          },


          getList: function() {
            var that = this;
            axios.get(api_url, {
                params: {
                  action: 'listPost',
                  //post_id: this.post_id
                }
              })
              .then(function(response) {
                if (response.status == 200) {
                  //post_list = response.data[0]
                  // console.log(post_list)
                  that.dataList = response.data;
                  console.log(that.dataList)
                }


              })
              .catch(function(error) {
                console.log(error);
              });

          },



          getDate: function(date) {
            var now = new Date(date),
              y = now.getFullYear(),
              m = now.getMonth() + 1,
              d = now.getDate();
            return y + "-" + (m < 10 ? "0" + m : m) + "-" + (d < 10 ? "0" + d : d) + " " + now.toTimeString().substr(0, 8);
          },


          /*
           * Encode a string as utf-8.
           * For efficiency, this assumes the input is valid utf-16.
           */
          hash: function(input) {
            var output = hex_md5(input)
            return output;
          },


          drawd3: function() {
            var that = this;
            axios.get("chartjson.php", {
                params: {
                  action: 'listPost',
                  //post_id: this.post_id
                }
              })
              .then(function(response) {
                if (response.status == 200) {
                  //post_list = response.data[0]
                  // console.log(post_list)
                  dataset = response.data;
                  drawsvg();
                  console.log(that.dataList)
                }


              })
              .catch(function(error) {
                console.log(error);
              });
          },


        },

        created: function() {
          var that = this;
          that.getPost(block_id)
          that.getTracking(block_id)
          that.drawd3()
        },
      })


      //获取当前日期 时间
      function todayTime() {
        var date = new Date();
        var curYear = date.getFullYear();
        var curMonth = date.getMonth() + 1;
        var curDate = date.getDate();
        if (curMonth < 10) {
          curMonth = '0' + curMonth;
        }
        if (curDate < 10) {
          curDate = '0' + curDate;
        }
        var curHours = date.getHours();
        var curMinutes = date.getMinutes();
        var curtime = curYear + ' 年 ' + curMonth + ' 月 ' + curDate + ' 日' + curHours + '时 ' + curMinutes + '分 ';
        return curtime;
      }
  </script>


</body>

</html>